package soft1921.spring.boot.mbp.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import soft1921.spring.boot.mbp.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
